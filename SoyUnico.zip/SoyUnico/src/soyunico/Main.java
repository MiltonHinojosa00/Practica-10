/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soyunico;


public class Main {

    public static void main(String[] args) {
        
        SoyUnico milton = SoyUnico.getSingletonInstance("Milton Hinojosa");
        SoyUnico marlon = SoyUnico.getSingletonInstance("Marlon Hinojosa");
        
        // ricardo y ramon son referencias a un único objeto de la clase SoyUnico
        System.out.println(milton.getNombre());
        System.out.println(marlon.getNombre());   
    }
}

